//
//  main.m
//  ApplicationSettings
//
//  Created by Wei-Meng Lee on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ApplicationSettingsAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ApplicationSettingsAppDelegate class]));
    }
}
